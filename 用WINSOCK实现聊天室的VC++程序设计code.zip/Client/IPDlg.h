#if !defined(AFX_IPDLG_H__129B5722_DAE2_11D2_A094_00002503C332__INCLUDED_)
#define AFX_IPDLG_H__129B5722_DAE2_11D2_A094_00002503C332__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIPDlg dialog

class CIPDlg : public CDialog
{
// Construction
public:
	CIPDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CIPDlg)
	enum { IDD = IDD_IPDLG };
	CString	m_csIP;
	short  m_iPort;
	CString	m_csName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIPDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPDLG_H__129B5722_DAE2_11D2_A094_00002503C332__INCLUDED_)
