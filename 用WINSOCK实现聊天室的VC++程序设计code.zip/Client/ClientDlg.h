// ClientDlg.h : header file
//

#if !defined(AFX_CLIENTDLG_H__129B571A_DAE2_11D2_A094_00002503C332__INCLUDED_)
#define AFX_CLIENTDLG_H__129B571A_DAE2_11D2_A094_00002503C332__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

//#define MAXLINE 10000

class CClientDlg : public CDialog
{
// Construction
public:
	virtual  ~CClientDlg();
	CClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClientDlg)
	enum { IDD = IDD_CLIENT_DIALOG };
	CString	m_csSend;
	CString	m_csRead;
	CString	m_csName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
//	BOOL m_bLogin;
	void OnSocketConnect();
	SOCKET m_hSocket;
	unsigned short m_iPort;
//	CString m_csName;
	CString m_csIP;
	HICON m_hIcon;
	void ReportWinsockErr(LPSTR lpszErrorMsg);

	// END MODIFICATIONS: Server Code

	// Generated message map functions
	//{{AFX_MSG(CClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAbout();
	afx_msg void OnLogin();
	afx_msg void OnLogout();
	afx_msg void OnSocketSend();
	//}}AFX_MSG
	afx_msg LRESULT OnSocketRead(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTDLG_H__129B571A_DAE2_11D2_A094_00002503C332__INCLUDED_)
