// ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "ClientDlg.h"
#include "IPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

CClientDlg::CClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientDlg)
	m_csSend = _T("");
	m_csRead = _T("");
	m_csName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientDlg)
	DDX_Text(pDX, IDC_EDIT_SEND, m_csSend);
	DDV_MaxChars(pDX, m_csSend, 60);
	DDX_Text(pDX, IDC_EDIT_READ, m_csRead);
	DDX_Text(pDX, IDC_EDIT_NAME, m_csName);
	DDV_MaxChars(pDX, m_csName, 8);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialog)
	//{{AFX_MSG_MAP(CClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_LOGIN, OnLogin)
	ON_BN_CLICKED(IDC_LOGOUT, OnLogout)
	ON_BN_CLICKED(IDC_SEND, OnSocketSend)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SOCKET_READ, OnSocketRead) 
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClientDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();

}

void CClientDlg::OnLogin() 
{
	// TODO: Add your control notification handler code here
	BOOL IsOK;
	CIPDlg ip;
	IsOK=ip.DoModal();
	if(IsOK==IDOK)
	{
		m_csIP=ip.m_csIP;
		m_iPort=htons(ip.m_iPort);
		m_csName=ip.m_csName;
		OnSocketConnect();
	}
	return;
}

void CClientDlg::OnLogout() 
{
	// TODO: Add your control notification handler code here
	if(m_hSocket!=INVALID_SOCKET)
	{
		closesocket(m_hSocket);
		WSACleanup();
	}
	m_csRead="";
	m_csSend="";
	UpdateData(FALSE);
	GetDlgItem(IDC_LOGIN)->EnableWindow(TRUE);
	GetDlgItem(IDC_LOGOUT)->EnableWindow(FALSE);
	GetDlgItem(IDC_SEND)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_SEND)->EnableWindow(FALSE);

	return;
}

void CClientDlg::OnSocketConnect()
{
	WSADATA wsaData;
	DWORD dwIPAddr;
	SOCKADDR_IN sockAddr;

	if(WSAStartup(WINSOCK_VERSION,&wsaData))
	{
		MessageBox("Could not load Windows Sockets DLL.",NULL,MB_OK);
		return;
	}
	
	
	if((dwIPAddr=inet_addr(m_csIP))==INADDR_NONE)
	{
		MessageBox("IPAddress is error!\nPlease input again!",NULL,MB_OK);
		return;
	}
	else
	{
		m_hSocket=socket(PF_INET,SOCK_STREAM,0);
		sockAddr.sin_family=AF_INET;
		sockAddr.sin_port=m_iPort;
		sockAddr.sin_addr.S_un.S_addr=dwIPAddr;
		int nConnect=connect(m_hSocket,(LPSOCKADDR)&sockAddr,sizeof(sockAddr));
		if(nConnect)
			ReportWinsockErr("Connect is error!!");
		else
			MessageBox("Successfully connected Server!!",NULL,MB_OK);

		int iErrorCode=WSAAsyncSelect(m_hSocket,m_hWnd,WM_SOCKET_READ,FD_READ);
		if(iErrorCode==SOCKET_ERROR)
			MessageBox("WSAAsyncSelect failed on socket",NULL,MB_OK);
		m_csRead="";
		GetDlgItem(IDC_LOGIN)->EnableWindow(FALSE);
		GetDlgItem(IDC_LOGOUT)->EnableWindow(TRUE);
		GetDlgItem(IDC_SEND)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SEND)->EnableWindow(TRUE);
		UpdateData(FALSE);
	}
}


LRESULT CClientDlg::OnSocketRead(WPARAM wParam,LPARAM lParam)
{
	int iBytesRead;
	int iBufferLength;
	int iEnd;
	int iSpaceRemaining;
	char chIncomingDataBuffer[100];
	
	iBufferLength = iSpaceRemaining = sizeof(chIncomingDataBuffer);
	iEnd = 0;
	iSpaceRemaining -= iEnd;
	
	iBytesRead = recv(m_hSocket, (LPSTR)(chIncomingDataBuffer+iEnd), iSpaceRemaining, 0);
	
	iEnd+=iBytesRead;
	
	if (iBytesRead == SOCKET_ERROR)
		ReportWinsockErr("OnClientRead recv reported a socket error.  ");
	
	chIncomingDataBuffer[iEnd] = '\0';

	if (lstrlen(chIncomingDataBuffer) != 0)
	{
		m_csRead=m_csRead+"\r\n"+chIncomingDataBuffer;
		GetDlgItem(IDC_EDIT_READ)->SetWindowText((LPCSTR)m_csRead);
//		UpdateData(FALSE); Getline
		CEdit *pEdit;
		pEdit=(CEdit *)GetDlgItem(IDC_EDIT_READ);
		int i=pEdit->GetLineCount();
		pEdit->LineScroll(i,0);
	}
	else
		;
	// Since Windows send notification of FD_READ and FD_CLOSE,
	// assume the client has closed the connection if zero bytes
	// are received. The program uses a blocking socket, which means if the
	// connection were still open, recv() would wait for data.
	//OnClientClose();
	
	return(0L);
	
}

void CClientDlg::OnSocketSend() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	m_csSend.TrimLeft();
	m_csSend.TrimRight();
	if(!m_csSend.IsEmpty())
	{
		m_csSend=m_csName+":"+m_csSend+"\n";
		int nCharSend=send(m_hSocket,m_csSend,m_csSend.GetLength(),0);
		if(nCharSend==SOCKET_ERROR)
			MessageBox("Error occurred during send!!",NULL,MB_OK);
	}
	m_csSend="";
	UpdateData(FALSE);

	CWnd *pEdit=GetDlgItem(IDC_EDIT_SEND);
	pEdit->SetFocus();
	
	return ;

}

VOID CClientDlg::ReportWinsockErr(LPSTR lpszErrorMsg)
{
	char m_chMsgBuffer[100];
	wsprintf(m_chMsgBuffer, "\nWinsock error %d: %s\n\n", WSAGetLastError(), lpszErrorMsg);
	MessageBeep(MB_ICONSTOP);
	MessageBox(m_chMsgBuffer,  AfxGetAppName(), MB_OK|MB_ICONSTOP);
	return;
}
// END MODIFICATIONS: Server Code

CClientDlg::~CClientDlg()
{
	if(m_hSocket!=INVALID_SOCKET)
	{
		closesocket(m_hSocket);
		WSACleanup();
	}
}


