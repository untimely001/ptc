// IPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "IPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIPDlg dialog


CIPDlg::CIPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIPDlg)
	m_csIP = _T("");
	m_iPort = 5000	;
	m_csName = _T("guest");
	//}}AFX_DATA_INIT
}


void CIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIPDlg)
	DDX_Text(pDX, IDC_EDIT1, m_csIP);
	DDX_Text(pDX, IDC_EDIT2, m_iPort);
	DDV_MinMaxInt(pDX, m_iPort, 0, 9999);
	DDX_Text(pDX, IDC_EDIT3, m_csName);
	DDV_MaxChars(pDX, m_csName, 8);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIPDlg, CDialog)
	//{{AFX_MSG_MAP(CIPDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIPDlg message handlers

void CIPDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();
	m_csIP.TrimLeft();
	m_csIP.TrimRight();
	if(m_csIP.IsEmpty())
	{
		MessageBox("IPAdress isn empty!\nPlesas Input again!",NULL,MB_OK);
		return ;
	}
	m_csName.TrimLeft();
	m_csName.TrimRight();
	if(m_csName.IsEmpty())
	{
		MessageBox("Name is empty!\nPlesas Input again!",NULL,MB_OK);
		return ;
	}
	int i=m_csName.GetLength();
	for(int j=0;j<8-i;j++)
		m_csName+=" ";
	UpdateData(FALSE);
	UpdateData();
	CDialog::OnOK();
}
