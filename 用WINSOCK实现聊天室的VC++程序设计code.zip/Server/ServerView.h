// ServerView.h : interface of the CServerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVERVIEW_H__F6D59302_D20F_11D2_B43D_00002503C332__INCLUDED_)
#define AFX_SERVERVIEW_H__F6D59302_D20F_11D2_B43D_00002503C332__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define MAXClient 10
/*
class CClientSock
{
public:
	SOCKET m_hSock;
	CString m_strName; //
	CClientSock(){m_hsock=INVALID_SOCKET;m_strName="";};
};
*/
class CServerView : public CScrollView
{
private:
	// START CUSTOM CODE: Internet Programming
 	char m_chMsgBuffer[100];
//	SOCKET m_hClientSocket;
	SOCKADDR_IN m_sockClientAddr;		// Socket address structure
	BOOL m_bServerIsOpen;
	CServerDoc *m_pDoc;
	CWnd *m_pParentWnd;
	CMenu *m_pParentMenu;
	SOCKET m_aClientSocket[MAXClient];  //Client Sock array
	// END MODIFICATIONS: Internet Programming

protected: // create from serialization only
	CServerView();
	DECLARE_DYNCREATE(CServerView)

// Attributes
public:
	CServerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
// START CUSTOM CODE: Internet Programming
	virtual void ReportWinsockErr(LPSTR lpszErrorMsg);
	virtual void PrintChar(char chChar, BOOL bLastChar);
	virtual void PrintString(LPSTR lpszString);
	virtual void PrintString(CString csString);
// END MODIFICATIONS: Internet Programming

public:
	virtual ~CServerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CServerView)
		afx_msg void OnServerClose();
		afx_msg void OnServerOpen();
	afx_msg void OnUpdateServerOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateServerClose(CCmdUI* pCmdUI);
	//}}AFX_MSG

	// START CUSTOM CODE: Internet Programming
	afx_msg LRESULT OnServerAccept(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnClientClose(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnClientRead(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnClientReadClose(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnServerBroadcast(char acSendBuff[]);
	// END MODIFICATIONS: Internet Programming

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ServerView.cpp
inline CServerDoc* CServerView::GetDocument()
   { return (CServerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERVIEW_H__F6D59302_D20F_11D2_B43D_00002503C332__INCLUDED_)
