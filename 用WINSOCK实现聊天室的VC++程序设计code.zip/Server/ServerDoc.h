// ServerDoc.h : interface of the CServerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVERDOC_H__C74B0561_D17F_11D2_B43D_00002503C332__INCLUDED_)
#define AFX_SERVERDOC_H__C74B0561_D17F_11D2_B43D_00002503C332__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

const MAX_LINES =100000;

class CServerDoc : public CDocument
{
protected: // create from serialization only
	CServerDoc();
	DECLARE_DYNCREATE(CServerDoc)

// Attributes
public:
	// START CUSTOM CODE: Server Code
	CString m_csText[MAX_LINES];										// CString array -- one per line
	LONG m_lLineNumber, m_lColumnNumber;
	UINT m_nServerPort;															// Server socket handle
	SOCKET m_hServerSocket;													// Server port
	SOCKADDR_IN m_sockServerAddr;//, m_sockClientAddr;	// Socket address structure
//	LPHOSTENT m_lpHostEntry;												// Internet host information structure
//	LPSERVENT m_lpServEntry;												// Service information structure
	// END MODIFICATIONS: Server Code

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerDoc)
	public:
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CServerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CServerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERDOC_H__C74B0561_D17F_11D2_B43D_00002503C332__INCLUDED_)
