// Server.h : main header file for the SERVER application
//

#if !defined(AFX_SERVER_H__C74B055B_D17F_11D2_B43D_00002503C332__INCLUDED_)
#define AFX_SERVER_H__C74B055B_D17F_11D2_B43D_00002503C332__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

// START CUSTOM CODE: Server Code
#include <winsock.h>

const int WINSOCK_VERSION = 0x0101;		// Required Winsock version 1.1
const int DEFAULT_PROTOCOL  = 0;			// No protocol specified, use default
const int NO_FLAGS = 0;								// No special flags specified
const int MAX_COLUMNS = 80;						// Maximum columns for text display
const int QUEUE_SIZE = 5;							// Maximum number of incoming 
																			// connections to queue
// Server-defined application messages
const int WM_SERVER_ACCEPT = WM_USER+101;
const int WM_CLIENT_CLOSE = WM_USER+102;
const int WM_CLIENT_READ = WM_USER+103;
const int WM_CLIENT_READCLOSE=WM_USER+105;
// END MODIFICATIONS: Server Code


/////////////////////////////////////////////////////////////////////////////
// CServerApp:
// See Server.cpp for the implementation of this class
//

class CServerApp : public CWinApp
{
private:
	// START CUSTOM CODE: Server Code
 	char chMsgBuffer[100]; 
	// END MODIFICATIONS: Server Code

public:
	// START CUSTOM CODE: Server Code
	WSADATA wsaData;
	// END MODIFICATIONS: Server Code

	CServerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CServerApp)
	afx_msg void OnAppAbout();
	afx_msg void OnServerClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVER_H__C74B055B_D17F_11D2_B43D_00002503C332__INCLUDED_)
